package com.example.haseeb.chiselapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class DisplayList extends AppCompatActivity {
    String Jstring;
    JSONObject jsonObject;
    JSONArray jsonArray;
    gta3adapter gtaadapter;
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_list);
        listView = (ListView) findViewById(R.id.listview);
        setTitle("Grand Theft Auto III");
        gtaadapter = new gta3adapter(this, R.layout.row_layout);
        listView.setAdapter(gtaadapter);
        Jstring = getIntent().getExtras().getString("json_data");
        try {
            jsonObject = new JSONObject(Jstring);
            int count = 0;
            jsonArray = jsonObject.getJSONArray("server_response");
            String info, type, code;
            while(count < jsonArray.length()){
            JSONObject JO = jsonArray.getJSONObject(count);
                info = JO.getString("info");

                code = JO.getString("code");
                gta3 game = new gta3(info, code);
                gtaadapter.add(game);
                count++;
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
