package com.example.haseeb.chiselapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class gta3adapter extends ArrayAdapter {
    List list = new ArrayList();
    public gta3adapter(Context context, int resource) {
        super(context, resource);
    }


    public void add(gta3 object) {
        super.add(object);
        list.add(object);
    }
    public int getCount(){
        return list.size();
    }


    @Override
    public Object getItem(int position) {
        return list.get(position);

    }

    @Override
    public View getView(int position, View convertView,ViewGroup parent) {
        View row;
        row = convertView;
        GtaHolder gtaHolder;
        if(row == null){
            LayoutInflater layoutInflater = (LayoutInflater) this.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row = layoutInflater.inflate(R.layout.row_layout,parent,false);
            gtaHolder = new GtaHolder();
            gtaHolder.tx_info = (TextView) row.findViewById(R.id.tx_info);

            gtaHolder.tx_code = (TextView) row.findViewById(R.id.tx_code);
            row.setTag(gtaHolder);
        }else{
            gtaHolder = (GtaHolder) row.getTag();
        }
        gta3 game = (gta3)this.getItem(position);
        gtaHolder.tx_info.setText(game.getInfo());

        gtaHolder.tx_code.setText(game.getCode());
        return row;
    }
    static class GtaHolder{
        TextView tx_info, tx_code;
    }
}
