package com.example.haseeb.chiselapp;

public class gta3 {

    private String info,type,code;
    public gta3(String info, String code){
        this.setInfo(info);

        this.setCode(code);
    }
    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }



    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
