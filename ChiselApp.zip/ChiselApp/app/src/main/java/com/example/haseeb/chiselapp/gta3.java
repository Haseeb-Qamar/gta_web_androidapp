package com.example.haseeb.chiselapp;

public class gta3 {

    private String info,type,code;
    public gta3(String info, String type, String code){
        this.setInfo(info);
        this.setType(type);
        this.setCode(code);
    }
    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
